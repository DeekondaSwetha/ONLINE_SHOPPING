package com.eshoppingzone.produt.exception;

public class ProductTypeNotExistsException extends RuntimeException{

	public ProductTypeNotExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductTypeNotExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductTypeNotExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
