package com.eshoppingzone.profile.exception;

public class ProfileAlreadyExistsException extends RuntimeException {

	public ProfileAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProfileAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProfileAlreadyExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
	

}
