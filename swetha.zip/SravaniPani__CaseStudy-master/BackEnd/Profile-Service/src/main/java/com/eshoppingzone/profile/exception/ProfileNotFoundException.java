package com.eshoppingzone.profile.exception;

public class ProfileNotFoundException extends RuntimeException {

	public ProfileNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProfileNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProfileNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
    
    

}
