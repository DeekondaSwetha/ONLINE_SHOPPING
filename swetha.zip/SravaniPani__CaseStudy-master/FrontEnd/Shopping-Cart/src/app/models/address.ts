export class Address {
    houseNumber:number;
    streetName:string;
    colonyName:string;
    city:string;
    pincode:number;
}
