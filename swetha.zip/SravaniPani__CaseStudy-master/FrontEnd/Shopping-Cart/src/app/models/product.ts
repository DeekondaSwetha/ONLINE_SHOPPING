export class Product {
    productId:number;
    productType:string;
    productName:string;
    category:string;
    rating:string;
    review:string;
    image:string;
    price:number;
    description:string;
    specification:string


}
